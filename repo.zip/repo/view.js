(function () {
    'use strict';

    angular
        .module(HygieiaConfig.module)
        .controller('RepoViewController', RepoViewController);

    RepoViewController.$inject = ['$q', '$scope','codeRepoData', 'pullRepoData', 'issueRepoData', 'collectorData', '$uibModal'];
    function RepoViewController($q, $scope, codeRepoData, pullRepoData, issueRepoData, collectorData, $uibModal) {
        var ctrl = this;

        ctrl.combinedChartOptions = {
            plugins: [
                Chartist.plugins.gridBoundaries(),
                Chartist.plugins.lineAboveArea(),
                Chartist.plugins.pointHalo(),
                Chartist.plugins.ctPointClick({
                    onClick: showDetail
                }),
                Chartist.plugins.axisLabels({
                    stretchFactor: 1.4,
                    showArea: false,
            lineSmooth: false,
            fullWidth: false,
                    axisX: {
                        labels: [
                            moment().subtract(60, 'days').format('MMM DD'),
                            moment().subtract(30, 'days').format('MMM DD'),
                            moment().format('MMM DD')
                        ]
                    }
                }),
                Chartist.plugins.ctPointLabels({
                    textAnchor: 'middle'
                })
            ],

            showArea: false,
            lineSmooth: false,
            fullWidth: true,
            axisY: {
                offset: 60,
                showGrid: true,
                showLabel: true,
                labelInterpolationFnc: function (value) {
                    return Math.round(value * 100) / 100;
                }
            }
        };

        ctrl.commits = [];
        ctrl.pulls = [];
        // ctrl.issues = [];

        ctrl.showDetail = showDetail;
        ctrl.load = function() {
            var deferred = $q.defer();
            var params = {
                componentId: $scope.widgetConfig.componentId,
                numberOfDays: 60
            };

            codeRepoData.details(params).then(function (data) {
                processCommitResponse(data.result, params.numberOfDays);
                ctrl.lastUpdated = data.lastUpdated;
            }).then(function () {
                collectorData.getCollectorItem($scope.widgetConfig.componentId, 'scm').then(function (data) {
                    deferred.resolve( {lastUpdated: ctrl.lastUpdated, collectorItem: data});
                });
            });
            pullRepoData.details(params).then(function (data) {
                processPullResponse(data.result, params.numberOfDays);
                ctrl.lastUpdated = data.lastUpdated;
            }).then(function () {
                collectorData.getCollectorItem($scope.widgetConfig.componentId, 'scm').then(function (data) {
                    deferred.resolve( {lastUpdated: ctrl.lastUpdated, collectorItem: data});
                });
            });
            issueRepoData.details(params).then(function (data) {
                processIssueResponse(data.result, params.numberOfDays);
                ctrl.lastUpdated = data.lastUpdated;
            }).then(function () {
                collectorData.getCollectorItem($scope.widgetConfig.componentId, 'scm').then(function (data) {
                    deferred.resolve( {lastUpdated: ctrl.lastUpdated, collectorItem: data});
                });
            });
            
            return deferred.promise;
        };

        function showDetail(evt) {
            var target = evt.target,
                pointIndex = target.getAttribute('ct:point-index');

            var seriesIndex = target.getAttribute('ct:series-index');

            //alert(ctrl);
            $uibModal.open({
                controller: 'RepoDetailController',
                controllerAs: 'detail',
                templateUrl: 'components/widgets/repo/detail.html',
                size: 'lg',

                resolve: {
                    commits: function() {
                        if (seriesIndex == "0")
                            return groupedCommitData[pointIndex];
                    },
                    pulls: function() {
                       if (seriesIndex == "1")
                            return groupedpullData[pointIndex];
                    },
                    issues: function() {
                       if (seriesIndex == "2")
                            return groupedissueData[pointIndex];
                    }
                }
            });
        }

        var commits = [];
        var groupedCommitData = [];
        function processCommitResponse(data, numberOfDays) {
            commits = [];
            groupedCommitData = [];
            // get total commits by day
            var groups = _(data).sortBy('timestamp')
                .groupBy(function (item) {
                    return -1 * Math.floor(moment.duration(moment().diff(moment(item.scmCommitTimestamp))).asDays());
                }).value();

            for (var x = -1 * numberOfDays + 1; x <= 0; x++) {
                if (groups[x]) {
                    commits.push(groups[x].length);
                    groupedCommitData.push(groups[x]);
                }
                else {
                    commits.push(0);
                    groupedCommitData.push([]);
                }
            }
            var labels = [];
            _(commits).forEach(function (c) {
                labels.push('');
            });
            //update charts
            if (commits.length)
            {
                ctrl.commitChartData = {
                    series: [commits],
                    labels: labels
                };
            }
            ctrl.combinedChartData = {
                labels: labels,
                series: [{
                    name: 'commits',
                    data: commits
                }, {
                    name: 'pulls',
                    data: pulls
                }, {
                    name: 'issues',
                    data: issues
                }]
            };

            // group get total counts and contributors
            var today = toMidnight(new Date());
            var thirtyDays = toMidnight(new Date());
            var sixtyDays = toMidnight(new Date());
            thirtyDays.setDate(thirtyDays.getDate() - 30);
            sixtyDays.setDate(sixtyDays.getDate() - 60);

            var lastDayCommitCount = 0;
            var lastDayCommitContributors = [];

            var lastthirtyDayCommitCount = 0;
            var lastthirtyDaysCommitContributors = [];

            var lastsixtyDayCommitCount = 0;
            var lastsixtyDaysCommitContributors = [];

            // loop through and add to counts
            _(data).forEach(function (commit) {

                if(commit.scmCommitTimestamp >= today.getTime()) {
                    lastDayCommitCount++;

                    if(lastDayCommitContributors.indexOf(commit.scmAuthor) == -1) {
                        lastDayCommitContributors.push(commit.scmAuthor);
                    }
                }

                if(commit.scmCommitTimestamp >= thirtyDays.getTime()) {
                    lastthirtyDayCommitCount++;

                    if(lastthirtyDaysCommitContributors.indexOf(commit.scmAuthor) == -1) {
                        lastthirtyDaysCommitContributors.push(commit.scmAuthor);
                    }
                }

                if(commit.scmCommitTimestamp >= sixtyDays.getTime()) {
                    lastsixtyDayCommitCount++;
                    ctrl.commits.push(commit);
                    if(lastsixtyDaysCommitContributors.indexOf(commit.scmAuthor) == -1) {
                        lastsixtyDaysCommitContributors.push(commit.scmAuthor);
                    }
                }
            });

            ctrl.lastDayCommitCount = lastDayCommitCount;
            ctrl.lastDayCommitContributorCount = lastDayCommitContributors.length;
            ctrl.lastthirtyDaysCommitCount = lastthirtyDayCommitCount;
            ctrl.lastthirtyDaysCommitContributorCount = lastthirtyDaysCommitContributors.length;
            ctrl.lastsixtyDaysCommitCount = lastsixtyDayCommitCount;
            ctrl.lastsixtyDaysCommitContributorCount = lastsixtyDaysCommitContributors.length;


            function toMidnight(date) {
                date.setHours(0, 0, 0, 0);
                return date;
            }
        }

        var pulls = [];
        var groupedpullData = [];
        function processPullResponse(data, numberOfDays) {
            pulls = [];
            groupedpullData = [];
            // get total pulls by day
            var groups = _(data).sortBy('timestamp')
                .groupBy(function(item) {
                    return -1 * Math.floor(moment.duration(moment().diff(moment(item.timestamp))).asDays());
                }).value();

            for(var x=-1*numberOfDays+1; x <= 0; x++) {
                if(groups[x]) {
                    pulls.push(groups[x].length);
                    groupedpullData.push(groups[x]);
                }
                else {
                    pulls.push(0);
                    groupedpullData.push([]);
                }
            }
            var labels = [];
            _(pulls).forEach(function() {
                labels.push('');
            });
            //update charts
            if(pulls.length)
            {
                ctrl.pullChartData = {
                    series: [pulls],
                    labels: labels
                };

            }
            ctrl.combinedChartData = {
                labels: labels,
                series: [{
                    name: 'commits',
                    data: commits
                }, {
                    name: 'pulls',
                    data: pulls
                }, {
                    name: 'issues',
                    data: issues
                }]
            };

            // group get total counts and contributors
            var today = toMidnight(new Date());
            var thirtyDays = toMidnight(new Date());
            var sixtyDays = toMidnight(new Date());
            thirtyDays.setDate(thirtyDays.getDate() - 30);
            sixtyDays.setDate(sixtyDays.getDate() - 60);

            var lastDayPullCount = 0;
            var lastDayPullContributors = [];

            var lastthirtyDayPullCount = 0;
            var lastthirtyDaysPullContributors = [];

            var lastsixtyDayPullCount = 0;
            var lastsixtyDaysPullContributors = [];

            // loop through and add to counts
            _(data).forEach(function (pull) {

                if(pull.timestamp >= today.getTime()) {
                    lastDayPullCount++;

                    if(lastDayPullContributors.indexOf(pull.userId) == -1) {
                        lastDayPullContributors.push(pull.userId);
                    }
                }
                if(pull.timestamp >= thirtyDays.getTime()) {
                    lastthirtyDayPullCount++;

                    if(lastthirtyDaysPullContributors.indexOf(pull.userId) == -1) {
                        lastthirtyDaysPullContributors.push(pull.userId);
                    }
                }
                if(pull.timestamp >= sixtyDays.getTime()) {
                    lastsixtyDayPullCount++;
                    ctrl.pulls.push(pull);
                    if(lastsixtyDaysPullContributors.indexOf(pull.userId) == -1) {
                        lastsixtyDaysPullContributors.push(pull.userId);
                    }
                }

            });

            ctrl.lastDayPullCount = lastDayPullCount;
            ctrl.lastDayPullContributorCount = lastDayPullContributors.length;
            ctrl.lastthirtyDaysPullCount = lastthirtyDayPullCount;
            ctrl.lastthirtyDaysPullContributorCount = lastthirtyDaysPullContributors.length;
            ctrl.lastsixtyDaysPullCount = lastsixtyDayPullCount;
            ctrl.lastsixtyDaysPullContributorCount = lastsixtyDaysPullContributors.length;

            function toMidnight(date) {
                date.setHours(0, 0, 0, 0);
                return date;
            }
        }
          
        var issues = [];
        var groupedissueData = [];
        function processIssueResponse(data, numberOfDays) {
            groupedissueData = [];
            issues = [];
            // get total issues by day
            var groups = _(data).sortBy('timestamp')
                .groupBy(function(item) {
                    return -1 * Math.floor(moment.duration(moment().diff(moment(item.timestamp))).asDays());
                }).value(); 

            for(var x=-1*numberOfDays+1; x <= 0; x++) {
                if(groups[x]) {
                    issues.push(groups[x].length);
                    groupedissueData.push(groups[x]);
                }
                else {
                    issues.push(0);
                    groupedissueData.push([]);
                }
            }
            var labels = [];
            _(issues).forEach(function() {
                labels.push('');
            });
            //update charts
            if(issues.length)
            {
                ctrl.issueChartData = {
                    series: [issues],
                    labels: labels
                };
            }
            ctrl.combinedChartData = {
                labels: labels,
                series: [{
                    name: 'commits',
                    data: commits
                }, {
                    name: 'pulls',
                    data: pulls
                }, {
                    name: 'issues',
                    data: issues
                }]
            };

            // group get total counts and contributors
            var today = toMidnight(new Date());
            var thirtyDays = toMidnight(new Date());
            var sixtyDays = toMidnight(new Date());
            thirtyDays.setDate(thirtyDays.getDate() - 30);
            sixtyDays.setDate(sixtyDays.getDate() - 60); 

            /* var lastDayIssueCount = 0;
            // var lastDayIssueContributors = [];

            var lastthirtyDayIssueCount = 0;
            var lastthirtyDaysIssueContributors = [];

            var lastsixtyDayIssueCount = 0;
            var lastsixtyDaysIssueContributors = []; */

            // loop through and add to counts
            /* _(data).forEach(function (issue) {

                if(issue.timestamp >= today.getTime()) {
                    lastDayIssueCount++;

                    if(lastDayIssueContributors.indexOf(issue.userId) == -1) {
                        lastDayIssueContributors.push(issue.userId);
                    }
                }
                if(issue.timestamp >= thirtyDays.getTime()) {
                    lastthirtyDayIssueCount++;

                    if(lastthirtyDaysIssueContributors.indexOf(issue.userId) == -1) {
                        lastthirtyDaysIssueContributors.push(issue.userId);
                    }
                }
                if(issue.timestamp >= sixtyDays.getTime()) {
                    lastsixtyDayIssueCount++;
                    ctrl.issues.push(issue);
                    if(lastsixtyDaysIssueContributors.indexOf(issue.userId) == -1) {
                        lastsixtyDaysIssueContributors.push(issue.userId);
                    }
                }

            });

            ctrl.lastDayIssueCount = lastDayIssueCount;
            ctrl.lastDayIssueContributorCount = lastDayIssueContributors.length;
            ctrl.lastthirtyDaysIssueCount = lastthirtyDayIssueCount;
            ctrl.lastthirtyDaysIssueContributorCount = lastthirtyDaysIssueContributors.length;
            ctrl.lastsixtyDaysIssueCount = lastsixtyDayIssueCount;
            ctrl.lastsixtyDaysIssueContributorCount = lastsixtyDaysIssueContributors.length; */

            function toMidnight(date) {
                date.setHours(0, 0, 0, 0);
                return date;
            }
        }
    }
})();
